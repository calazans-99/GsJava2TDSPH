package br.com.fiap.safeguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeguardApplication {
    public static void main(String[] args) {
        SpringApplication.run(SafeguardApplication.class, args);
    }
}
